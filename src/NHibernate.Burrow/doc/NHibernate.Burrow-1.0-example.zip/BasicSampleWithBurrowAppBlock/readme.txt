This is a modification to the basic sample that uses not only the Burrow Core but also Burrow.Util
As  "NH Best Practice sample" requests, this sample requires NorthWind DB to run. If you don't have the NorthWind DB on your machine, you can restore from the backup file in the Solution Items folder.

This is not a  NHibernate Burrow project template. 